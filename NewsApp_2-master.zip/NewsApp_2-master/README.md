# News App (Stage 2)

This app is a draft for a news app that shows news received from the Guardian API. I am not responsible for the news displayed. 

To use this app you need a key for the Guardian API. You can register for a key on (https://open-platform.theguardian.com/access/). Please add the key under: res > values > strings 

This app has been made for educational purposes as part of the Udacity Google Developer Scholarship Challenge 2017/18.

